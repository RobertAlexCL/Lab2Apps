package com.example.lab2


class FileList(override val lapHistory: ArrayList<Int>) : LapHistory {

//Esta es la lista que contiene las repeticiones que el usuario irá guardando
    override fun clear(){
        this.lapHistory.clear()
    }

    override fun del(elementIndex: Int){
        this.lapHistory.removeAt(elementIndex)
    }

    override fun add(element: Int){
        this.lapHistory.add(element)
    }

}