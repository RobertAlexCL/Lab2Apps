package com.example.lab2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var workouts = FileList(lapHistory = ArrayList())
        workouts.add(1)
        workouts.add(2)
        workouts.add(3)
        workouts.add(4)
        workouts.add(5)
        workouts.add(6)


        var listView = findViewById<ListView>(R.id.list_item)
        val ad = ArrayAdapter(this,android.R.layout.simple_list_item_1,workouts.lapHistory)
        listView.adapter = ad

        val delete = findViewById<Button>(R.id.button)
        delete.setOnClickListener{
            workouts.add(34)
            workouts.lapHistory.clear()
        }

        val nextButton = findViewById<Button>(R.id.button2)
        nextButton.setOnClickListener{
            val intent = Intent(this, Main2::class.java)
            startActivity(intent)
        }


    }

}
