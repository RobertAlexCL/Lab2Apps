package com.example.lab2

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.time.Instant

class Main2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main2)



        val menuB = findViewById<Button>(R.id.button10)
        menuB.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }




        val sub = findViewById<Button>(R.id.button4)
        sub.setOnClickListener {
            val CT = findViewById<TextView>(R.id.textView)
            val num = CT.text.toString().toInt() - 1
            CT.setText(num)
        }




        val add = findViewById<Button>(R.id.button3)
        add.setOnClickListener {
            val CT = findViewById<TextView>(R.id.textView)
            val num = CT.text.toString().toInt() + 1
            CT.setText(num)
        }
    }
}
